@extends('base')
@section('content')
<div class="container">
    <h3>アンケート回答ありがとうございました。</h3>
</div>
@endsection
