<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>アンケート回答ありがとうございました。</h3>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>